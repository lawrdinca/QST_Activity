package ro.ase.csie.cts.homework1.exceptions;

public class InvalidDaysException extends RuntimeException {

}
