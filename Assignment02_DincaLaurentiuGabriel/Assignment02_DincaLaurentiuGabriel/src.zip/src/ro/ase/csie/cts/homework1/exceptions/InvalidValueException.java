package ro.ase.csie.cts.homework1.exceptions;

public class InvalidValueException extends RuntimeException {

}
