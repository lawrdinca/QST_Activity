package ro.ase.csie.cts.homework1.exceptions;

public class InvalidInterestRateException extends RuntimeException {

}
