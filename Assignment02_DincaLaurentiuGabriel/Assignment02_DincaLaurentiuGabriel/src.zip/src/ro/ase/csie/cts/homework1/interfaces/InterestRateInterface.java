package ro.ase.csie.cts.homework1.interfaces;

public interface InterestRateInterface {

	public abstract double getMonthlyInterestRate(double loanValue, double interestRate);
}
